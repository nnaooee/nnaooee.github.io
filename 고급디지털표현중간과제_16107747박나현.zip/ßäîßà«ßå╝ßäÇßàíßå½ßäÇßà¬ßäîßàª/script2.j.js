$('#button01').hover(
    function(){
        $('#target01').css('display', 'block');
    },
    function(){
        $('#target01').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target02').css('display', 'block');
    },
    function(){
        $('#target02').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target03').css('display', 'block');
    },
    function(){
        $('#target03').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target04').css('display', 'block');
    },
    function(){
        $('#target04').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target05').css('display', 'block');
    },
    function(){
        $('#target05').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target06').css('display', 'block');
    },
    function(){
        $('#target06').css('display', 'none');
    }
);
$('#button01').hover(
    function(){
        $('#target07').css('display', 'block');
    },
    function(){
        $('#target07').css('display', 'none');
    }
);

$('#button01').click(
    function(){
        $('#target01').css({'width':'400px', 'height':'400px'});
    }
);